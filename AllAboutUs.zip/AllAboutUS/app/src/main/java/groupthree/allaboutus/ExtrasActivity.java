package groupthree.allaboutus;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class ExtrasActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_extras);
    }

    public void browser1(View view){
        Intent browserIntent=new Intent(Intent.ACTION_VIEW,Uri.parse("http://www.radford.edu/content/radfordcore/home.html"));
        startActivity(browserIntent);

    }

    public void browser2(View view){
        Intent browser2Intent=new Intent(Intent.ACTION_VIEW,Uri.parse("http://www.radford.edu/content/residence-life/home.html"));
        startActivity(browser2Intent);

    }

    public void browser3(View view){
        Intent browser3Intent=new Intent(Intent.ACTION_VIEW,Uri.parse("http://www.realtor.com"));
        startActivity(browser3Intent);

    }



    /**
     * Used to open the HomeActivity.
     * @param view
     */
    public void openHomeActivity(View view) {
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }
}
