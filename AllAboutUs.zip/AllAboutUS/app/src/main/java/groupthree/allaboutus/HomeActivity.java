package groupthree.allaboutus;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }

    /**
     * Used to open the HomeActivity.
     * @param view
     */
    public void openAboutUsActivity(View view) {
        Intent intent = new Intent(this, AboutUsActivity.class);
        startActivity(intent);
    }

    /**
     * Used to open the DetailsActivity.
     * @param view
     */
    public void openDetailsActivity(View view) {
        Intent intent = new Intent(this, DetailsActivity.class);
        startActivity(intent);
    }

    /**
     * Used to open the ExtrasActivity.
     * @param view
     */
    public void openExtrasActivity(View view) {
        Intent intent = new Intent(this, ExtrasActivity.class);
        startActivity(intent);
    }
}
